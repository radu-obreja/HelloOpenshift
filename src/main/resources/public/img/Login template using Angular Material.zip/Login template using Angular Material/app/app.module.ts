/*
Login template using Angular Material
@author Shashank Tiwari
*/

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {MdButtonModule, MdCheckboxModule,MdGridListModule,MdInputModule,MdIconModule} from '@angular/material';

import { AppComponent } from './app.component';

@NgModule({
	declarations: [
    	AppComponent
  	],
  	imports: [
    	BrowserModule,
    	MdButtonModule, 
    	MdCheckboxModule,
    	MdGridListModule,
    	MdInputModule,
    	MdIconModule,
    	BrowserAnimationsModule
  	],
  	providers: [],
  	bootstrap: [AppComponent]
})
export class AppModule { }